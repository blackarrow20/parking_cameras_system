# LICENSE
Parking cameras system  

**LICENSE**  
By this license you are allowed to sell and distribute this product, however 10% of product price is to be paid to author for every sold product, while project details are open-source including both: hardware and software. You can check my banking information here:  
https://github.com/blackarrow20/future_of_the_world/blob/main/My%20banking%20information.pdf  
My American Paypal account: ice_vii@engineer.com  
My Bosnian Paypal account: adajic91@gmail.com -> I don’t want money being sent to this one  

## Usage/Examples  

The device can be used for:
-	Street monitoring: when you are joining traffic from a parking spot, connect to the wireless access point with your mobile phone or tablet, and see footage from 2 cameras monitoring the street via website: http://192.168.0.200  
-	Connect directly to wireless access point with your mobile phone, PC or laptop within range, then access footage from cameras via website: http://192.168.0.200 If wifi is not within range, you can use long ethernet cable  
-	Monitoring of garden in front of your house  
-	Monitoring of the front door of the house  
-	You can use free software like FlashBack Express Recorder to record footage from those cameras while you are connected to the website http://192.168.0.200  
-	For smooth recording of video footage you can convert HDMI to MP4 with devices like: ClearClick HD Video Capture Box Ultimate. Or use combination of the following 2 devices, which is a cheaper option for getting 640 x 480 video capturing resolution:  
1.) HDMI to AV/S-Video converter  
2.) Elgato Video Capture - conversion from AV/S-Video to TS and/or MP4  