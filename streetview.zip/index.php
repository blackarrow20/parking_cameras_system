<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<script src="jquery.min.js"></script>
		<script src="script.js"></script>
		<script src="webcam1.js"></script>
		<script src="webcam2.js"></script>
		<script src="webcam3.js"></script>
	<title>Street view</title>
	</head>
	<body onload="setupWebcam1(); setupWebcam2(); setupWebcam3(); setInterval(repeatedCall, 250);" style="overflow: hidden; margin: 0; padding: 0;" id="page">
		<center>		
			<table cellspacing="0" cellpadding="0" border="0" id="videos_table" width="100%" style="border-spacing:0; border-collapse: collapse;">
				<tr>
					<td id="position0" valign="top" align="center"><div id="my_camera0" class="pre_capture_frame" style="display: block;"></div></td>
					<td id="position1" valign="top" align="center"><div id="my_camera1" class="pre_capture_frame" style="display: block;"></div></td>
				</tr>
				<tr>
					<td colspan="2" id="position2"><div id="my_camera2" class="pre_capture_frame" style="display: block;"></div></td>
				</tr>
			</table>					
		</center>
	</body>
</html>
