<?php
// *************************************************************************************************
// LICENSE
// By this license you are allowed to sell and distribute this product, however 10% of product price
// is to be paid to author for every sold product, while project details are open-source including 
// both: hardware and software. You can check my banking information here:
// https://github.com/blackarrow20/future_of_the_world/blob/main/My%20banking%20information.pdf
// My American Paypal account: ice_vii@engineer.com
// My Bosnian Paypal account: adajic91@gmail.com -> I don’t want money being sent to this one
// *************************************************************************************************

    $N = 0;
    
    $fp = fopen("N.txt", "c+");
    if (flock($fp, LOCK_EX)) {
        $N = intval(fgets($fp)) + 1;
        if ($N >= 601) $N = 1;
        rewind($fp);
        ftruncate($fp, 0);
        fwrite($fp, $N);
        fflush($fp);
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    function write1ToFile($file_name) {
        $fp = fopen($file_name, "w");
        fwrite($fp, "1");
        fflush($fp);
        fclose($fp);
    }    

    write1ToFile("img/$N.txt");

    /*
    $command = "cd $folder && python3 $folder/script.py > /dev/null 2>&1 &"; // This would start the script.py asynchroniously
    exec(
        $command,    // The command to execute.
        $output,     // A variable that will be filled with an array of all the lines returned.
        $result_code // The return status of the executed command.
    );
    var_export([
        '$command' => $command,
        '$output' => $output,
        '$last_line' => "",
        '$result_code' => $result_code,
    ]);    
    print("</br>");
    */
    
    while(1) {
        $fp = fopen("img/$N.txt", "r");
        if (!$fp) continue;
        $line = fgets($fp);
        if ($line != "0") {
            fclose($fp);
            continue;
        }
        fclose($fp);
        // Line is "0" here, we need to take new image
        $im1 = file_get_contents("img/img$N.png");
        $im2 = file_get_contents("img/img0$N.png");
        write1ToFile("img/$N.txt");
        $im1_data = "<img src='data:image/png;base64,".base64_encode($im1)."'>";
        $im2_data = "<img src='data:image/png;base64,".base64_encode($im2)."'>";
        // Pass this image via SSE
        print($im1_data . $im2_data);

        break;
    }
?>