	// Configure a few settings and attach camera 250x187
function setupWebcam1() {
	setTimeout(function () {
		var screen_width = $(window).width();
		var screen_height = $(window).height();
		if (screen_width >= screen_height) {
			Webcam1.set({width: Math.floor(screen_width/2.0), height: screen_height,	image_format: 'jpeg', jpeg_quality: 90});
		}
		if (screen_height > screen_width) {
			Webcam1.set({width: screen_width, height: Math.floor(screen_height/2.0), image_format: 'jpeg', jpeg_quality: 90});
		}
		Webcam1.attach( '#my_camera0' );
	}, 2000);	
}

function setupWebcam2() {
	setTimeout(function () {
		var screen_width = $(window).width();
		var screen_height = $(window).height();
		if (screen_width >= screen_height) {
			Webcam2.set({width: Math.floor(screen_width/2.0), height: screen_height, image_format: 'jpeg', jpeg_quality: 90});
		}
		if (screen_height > screen_width) {
			Webcam2.set({width: screen_width, height: Math.floor(screen_height/2.0), image_format: 'jpeg', jpeg_quality: 90});
		}
		Webcam2.attach( '#my_camera1' );
	}, 4000);
}

function setupWebcam3() {
	setTimeout(function () {
		var screen_width = $(window).width();
		var screen_height = $(window).height();
		if (screen_width >= screen_height) {
			Webcam3.set({width: screen_width, height: Math.floor(screen_height/2.0), image_format: 'jpeg', jpeg_quality: 90});
		}
		if (screen_height > screen_width) {
			Webcam3.set({width: screen_width, height: Math.floor(screen_height/2.0), image_format: 'jpeg', jpeg_quality: 90});
		}
		Webcam3.attach( '#my_camera2' );
	}, 6000);
}



function repeatedCall() {
	var videos = $("#videos_table").find("video");
	if (videos.length != 3) return;
	var screen_width = $(window).width();
	var screen_height = $(window).height();
	if (screen_width >= screen_height) {		
		$("#my_camera1").show();
		$("#my_camera2").hide();
	}
	else if (screen_height > screen_width) {			
		$("#my_camera2").show();
		$("#my_camera1").hide();
	}
	if (screen_width >= screen_height) {
		$("#position0").width(Math.floor(screen_width/2.0));
		$("#position1").width(Math.floor(screen_width/2.0));
		$("#position2").width(Math.floor(screen_width));
		$(videos[0]).width(Math.floor(screen_width/2.0));
		$(videos[1]).width(Math.floor(screen_width/2.0));
		$("#my_camera0").width(Math.floor(screen_width/2.0));
		$("#my_camera1").width(Math.floor(screen_width/2.0));

		$("#position0").height(screen_height);
		$("#position1").height(screen_height);
		$("#position2").height(0);
		$(videos[0]).height(screen_height);
		$(videos[1]).height(screen_height);
		$("#my_camera0").height(screen_height);
		$("#my_camera1").height(screen_height);
		return;
	}
	if (screen_height > screen_width) {
		$("#position0").width(screen_width);
		$("#position1").width(0);
		$("#position2").width(screen_width);
		$(videos[0]).width(screen_width);
		$(videos[2]).width(screen_width);
		$("#my_camera0").width(screen_width);
		$("#my_camera2").width(screen_width);

		$("#position0").height(Math.floor(screen_height/2.0));
		$("#position1").height(Math.floor(screen_height/2.0));
		$("#position2").height(Math.floor(screen_height/2.0) + 1);
		$(videos[0]).height(Math.floor(screen_height/2.0));
		$(videos[2]).height(Math.floor(screen_height/2.0) + 1);
		$("#my_camera0").height(Math.floor(screen_height/2.0));
		$("#my_camera2").height(Math.floor(screen_height/2.0) + 1);
		return;
	}
}