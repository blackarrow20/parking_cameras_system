<!DOCTYPE html>
<?php
// *************************************************************************************************
// LICENSE
// By this license you are allowed to sell and distribute this product, however 10% of product price
// is to be paid to author for every sold product, while project details are open-source including 
// both: hardware and software. You can check my banking information here:
// https://github.com/blackarrow20/future_of_the_world/blob/main/My%20banking%20information.pdf
// My American Paypal account: ice_vii@engineer.com
// My Bosnian Paypal account: adajic91@gmail.com -> I don’t want money being sent to this one
// *************************************************************************************************
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<script src="jquery.min.js"></script>
	<title>Street view</title>
	</head>
	<body style="margin: 0; padding: 0; overflow: hidden;" id="page">
		<center>
			<table cellspacing="0" cellpadding="0" border="0" id="videos_table" width="100%" style="border-spacing:0; border-collapse: collapse;">
				<tr>
					<td id="position0" valign="top" align="center"><span id="my_camera0" style="display: block;"><img id="img0" /></span></td>
					<td id="position1" valign="top" align="center"><span id="my_camera1" style="display: block;"><img id="img1" /></span></td>
				</tr>
				<tr>
					<td colspan="2" id="position2"><span id="my_camera2" style="display: block;"><img id="img2" /></span></td>
				</tr>
			</table>					
		</center>
		<script type="text/javascript">
			var oldUpdateTime1 = Math.floor(Date.now()); // Miliseconds
			var newUpdateTime1 = oldUpdateTime1;

			var oldUpdateTime2 = Math.floor(Date.now()); // Miliseconds
			var newUpdateTime2 = oldUpdateTime2;

			function resize() {
				var videos = $("#videos_table").find("img");
				if (videos.length != 3) return;
				var screen_width = $(window).width();
				var screen_height = $(window).height();
				if (screen_width >= screen_height) {		
					$("#my_camera1").show();
					$("#my_camera2").hide();
				}
				else if (screen_height > screen_width) {			
					$("#my_camera1").hide();
					$("#my_camera2").show();
				}
				if (screen_width >= screen_height) {
					$("#position0").width(Math.floor(screen_width/2.0));
					$("#position1").width(Math.floor(screen_width/2.0));
					$("#position2").width(Math.floor(screen_width));
					$(videos[0]).width(Math.floor(screen_width/2.0));
					$(videos[1]).width(Math.floor(screen_width/2.0));
					$("#my_camera0").width(Math.floor(screen_width/2.0));
					$("#my_camera1").width(Math.floor(screen_width/2.0));

					$("#position0").height(screen_height);
					$("#position1").height(screen_height);
					$("#position2").height(0);
					$(videos[0]).height(screen_height);
					$(videos[1]).height(screen_height);
					$("#my_camera0").height(screen_height);
					$("#my_camera1").height(screen_height);
					return;
				}
				if (screen_height > screen_width) {
					$("#position0").width(screen_width);
					$("#position1").width(0);
					$("#position2").width(screen_width);
					$(videos[0]).width(screen_width);
					$(videos[2]).width(screen_width);
					$("#my_camera0").width(screen_width);
					$("#my_camera2").width(screen_width);

					$("#position0").height(Math.floor(screen_height/2.0));
					$("#position1").height(Math.floor(screen_height/2.0));
					$("#position2").height(Math.floor(screen_height/2.0) + 1);
					$(videos[0]).height(Math.floor(screen_height/2.0));
					$(videos[2]).height(Math.floor(screen_height/2.0) + 1);
					$("#my_camera0").height(Math.floor(screen_height/2.0));
					$("#my_camera2").height(Math.floor(screen_height/2.0) + 1);
					return;
				}				
			};

			function preventiveMeasure() {
				newUpdateTime1 = Math.floor(Date.now()); // Miliseconds
				if (newUpdateTime1 - oldUpdateTime1 >= 1500) { // Remove images because they are stale, too old to be trusted - older than 1.5 secs
					oldUpdateTime1 = newUpdateTime1;					
					document.getElementById("img0").src = "";
					document.getElementById("img1").src = "";
					document.getElementById("img2").src = "";
				}

				newUpdateTime2 = Math.floor(Date.now()); // Miliseconds
				if (newUpdateTime2 - oldUpdateTime2 >= 1500) { // Remove images because they are stale, too old to be trusted - older than 1.5 secs
					oldUpdateTime2 = newUpdateTime2;					
					document.getElementById("img0").src = "";
					document.getElementById("img1").src = "";
					document.getElementById("img2").src = "";
				}
			}

			var eventSource = new EventSource("process.php");
			var img1;
			var img2;
			eventSource.onmessage = function(event) {				
				if (event.data[0] == "L") {
					oldUpdateTime1 = Math.floor(Date.now()); // Miliseconds				
					img1 = new Image();
					img1.src = "data:image/png;base64," + event.data.substring(1);
					img1.onload = function(){
						document.getElementById("img0").src = img1.src;
						resize();
					}
				} else if (event.data[0] == "R") {
					oldUpdateTime2 = Math.floor(Date.now()); // Miliseconds				
					img2 = new Image();
					img2.src = "data:image/png;base64," + event.data.substring(1);
					img2.onload = function(){
						document.getElementById("img1").src = img2.src;
						document.getElementById("img2").src = img2.src;
						resize();
					}
				}				
			};

			setInterval(preventiveMeasure, 25);

		</script>
	</body>
</html>