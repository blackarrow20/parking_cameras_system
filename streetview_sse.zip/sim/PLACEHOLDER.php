<?php
// *************************************************************************************************
// LICENSE
// By this license you are allowed to sell and distribute this product, however 10% of product price
// is to be paid to author for every sold product, while project details are open-source including 
// both: hardware and software. You can check my banking information here:
// https://github.com/blackarrow20/future_of_the_world/blob/main/My%20banking%20information.pdf
// My American Paypal account: ice_vii@engineer.com
// My Bosnian Paypal account: adajic91@gmail.com -> I don’t want money being sent to this one
// *************************************************************************************************
?>
